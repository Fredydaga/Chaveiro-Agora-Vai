'use client'

import {
  CarFront,
  Check,
  ChevronDown,
  Clock3,
  Home,
  KeyRound,
  LocateFixed,
  MapPin,
  ShieldCheck,
} from 'lucide-react'

const whatsappNumber = '5549988901379'
const generalMessage = 'Olá! Preciso de um chaveiro agora. Estou em: '

function whatsappLink(message = generalMessage) {
  return `https://wa.me/${whatsappNumber}?text=${encodeURIComponent(message)}`
}

function WhatsAppIcon() {
  return <img aria-hidden="true" className="whatsapp-icon" src="https://cdn.jsdelivr.net/gh/glincker/thesvg@main/public/icons/whatsapp/light.svg" alt="" />
}

function WhatsAppButton({ children, message = generalMessage, className = '' }: { children: React.ReactNode; message?: string; className?: string }) {
  return <a className={`whatsapp-button ${className}`} href={whatsappLink(message)} target="_blank" rel="noreferrer"><WhatsAppIcon /><span>{children}</span></a>
}

const trustItems = [
  { icon: Clock3, text: '24h por dia, 7 dias' },
  { icon: ShieldCheck, text: 'Sem danificar a porta' },
  { icon: Check, text: 'Preço combinado antes' },
  { icon: MapPin, text: 'Atende Chapecó e região' },
]

const faqs = [
  ['Quanto tempo demora para chegar?', 'Depende de onde você está, mas informamos o tempo exato quando você chama no WhatsApp.'],
  ['Quanto custa?', 'O valor é passado antes de qualquer serviço. Você só aprova se concordar.'],
  ['Vai estragar minha porta ou meu carro?', 'Não. Usamos técnicas e ferramentas profissionais para abrir sem danificar.'],
  ['Atende de madrugada?', 'Sim, 24 horas, todos os dias.'],
  ['Quais lugares atende?', 'Toda Chapecó e as cidades da região.'],
]

export default function Page() {
  return (
    <main>
      <header className="site-header">
        <div className="container header-inner">
          <a className="brand" href="#inicio" aria-label="Chaveiro Socorro Rápido 24h - início"><KeyRound aria-hidden="true" /><span>Chaveiro Socorro Rápido <strong>24h</strong></span></a>
          <div className="header-contact"><a href={`tel:+${whatsappNumber}`}>(49) 98890-1379</a><WhatsAppButton className="header-whatsapp">WhatsApp</WhatsAppButton></div>
        </div>
      </header>

      <section className="hero" id="inicio" aria-labelledby="hero-title">
        <div className="hero-image" aria-hidden="true" />
        <div className="container hero-inner">
          <p className="availability"><span /> Atendimento 24 horas</p>
          <div className="hero-copy">
            <p className="eyebrow">SOCORRO EMERGENCIAL EM CHAPECÓ</p>
            <h1 id="hero-title">Trancado para fora? <em>Chegamos rápido</em> em Chapecó e região.</h1>
            <p className="hero-subtitle">Abrimos sua casa ou seu carro sem danificar a fechadura. Atendimento 24 horas, inclusive fins de semana e feriados.</p>
            <WhatsAppButton className="hero-cta">Chamar chaveiro no WhatsApp</WhatsAppButton>
            <p className="microcopy"><Check aria-hidden="true" /> Responde em poucos minutos. Orçamento antes de começar.</p>
          </div>
          <p className="hero-note">Atendimento direto no local, sem loja física.</p>
        </div>
      </section>

      <section className="trust-strip" aria-label="Diferenciais"><div className="container trust-grid">{trustItems.map(({ icon: Icon, text }) => <div className="trust-item" key={text}><Icon aria-hidden="true" /><span>{text}</span></div>)}</div></section>

      <section className="section services" aria-labelledby="services-title"><div className="container"><p className="section-kicker">SOCORRO AGORA</p><h2 id="services-title">O que você precisa agora?</h2><p className="section-intro">Escolha o atendimento e fale direto com o chaveiro.</p><div className="service-grid">
        <article className="service-card"><div className="service-image home-image" role="img" aria-label="Porta residencial sendo aberta por um chaveiro" /><div className="service-content"><span className="card-label">CASA OU APARTAMENTO</span><h3>Trancado fora de casa</h3><p>Perdeu a chave, esqueceu dentro ou a chave quebrou na fechadura. Abrimos portas de casa e apartamento.</p><WhatsAppButton message="Olá! Estou trancado fora de casa. Estou em: ">Abrir minha casa</WhatsAppButton></div></article>
        <article className="service-card"><div className="service-image car-image" role="img" aria-label="Porta de carro sendo aberta por um chaveiro" /><div className="service-content"><span className="card-label">CARRO</span><h3>Trancado fora do carro</h3><p>Chave esquecida dentro do carro, no porta-malas ou perdida. Abrimos o carro sem quebrar vidro nem forçar a porta.</p><WhatsAppButton message="Olá! Estou trancado fora do carro. Estou em: ">Abrir meu carro</WhatsAppButton></div></article>
      </div></div></section>

      <section className="section how-section" aria-labelledby="how-title"><div className="container narrow"><p className="section-kicker">SIMPLES E SEM ENROLAÇÃO</p><h2 id="how-title">Como funciona</h2><div className="steps"><div className="step"><span>01</span><div><h3>Chame no WhatsApp</h3><p>Mande sua localização.</p></div></div><div className="step"><span>02</span><div><h3>Combinamos tudo</h3><p>Informamos o valor e o tempo de chegada.</p></div></div><div className="step"><span>03</span><div><h3>Resolvemos no local</h3><p>Chegamos e abrimos sem danos.</p></div></div></div><WhatsAppButton>Chamar agora pelo WhatsApp</WhatsAppButton></div></section>

      <section className="section why-section" aria-labelledby="why-title"><div className="container"><div className="why-layout"><div><p className="section-kicker">POR QUE A GENTE</p><h2 id="why-title">Ajuda de quem conhece a região.</h2><p className="section-intro">Socorro rápido, direto e transparente para você voltar para dentro sem estresse.</p></div><div className="why-list"><div><LocateFixed aria-hidden="true" /><p><strong>Técnico local de Chapecó</strong>Atendemos Chapecó e as cidades da região.</p></div><div><ShieldCheck aria-hidden="true" /><p><strong>Abertura sem danos</strong>Ferramentas profissionais próprias para cada situação.</p></div><div><Check aria-hidden="true" /><p><strong>Preço combinado antes</strong>Sem surpresa: você aprova antes de começar.</p></div><div><Clock3 aria-hidden="true" /><p><strong>Quando você precisar</strong>De madrugada, fins de semana e feriados.</p></div></div></div></div></section>

      <section className="section faq-section" aria-labelledby="faq-title"><div className="container narrow"><p className="section-kicker">AINDA COM DÚVIDA?</p><h2 id="faq-title">Dúvidas rápidas</h2><div className="faq-list">{faqs.map(([question, answer]) => <details key={question}><summary>{question}<ChevronDown aria-hidden="true" /></summary><p>{answer}</p></details>)}</div></div></section>

      <section className="final-cta"><div className="container"><p className="section-kicker">PRECISA DE AJUDA?</p><h2>Não fique na rua esperando.</h2><p>Chame agora e resolva em minutos.</p><WhatsAppButton>Chamar no WhatsApp agora</WhatsAppButton></div></section>
      <footer><div className="container footer-inner"><div><strong>Chaveiro Socorro Rápido 24h</strong><span>Atendimento 24h em Chapecó e região — SC</span><span>CNPJ: ____________________</span></div><a href={whatsappLink()} target="_blank" rel="noreferrer"><WhatsAppIcon /> (49) 98890-1379</a></div></footer>
      <a className="mobile-sticky" href={whatsappLink()} target="_blank" rel="noreferrer"><WhatsAppIcon /> Chamar no WhatsApp agora</a>
    </main>
  )
}

